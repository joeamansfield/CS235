#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

//determines grade based on score and average
char DetermineGrade(double examScore, double examAverage)
{
	if (examScore >= examAverage + 15)
	{
		return 'A';
	}
	else if (examScore > examAverage + 5)
	{
		return 'B';
	}
	else if (examScore <= examAverage - 15)
	{
		return 'E';
	}
	else if (examScore < examAverage - 5)
	{
		return 'D';
	}
	else
	{
		return 'C';
	}
}

int main(int argc, char** argv)
{
	//open and check input and output files
	if (argc < 3)
	{
		cerr << "Enter arguments for input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream inFile;
	inFile.open(argv[1]);
	if (!inFile)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream outFile;
	outFile.open(argv[2]);
	if (!outFile)
	{
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	int numStudents;
	int numExams;
	inFile >> numStudents;
	inFile >> numExams;

	//allocate memory
	double** gradeChart = new double*[numStudents + 6];
	string** nameChart = new string*[numStudents];
	for (int i = 0; i < numStudents + 6; i++)
	{
		gradeChart[i] = new double[numExams];
	}

	//initialize rows for average and total of each letter grade
	for (int i = 0; i < numExams; i++)
	{
		for (int j = 0; j < 6; j++)
		{
			gradeChart[numStudents + j][i] = 0;
		}
	}

	//populate arrays with names and grades
	for (int i = 0; i < numStudents; i++)
	{
		nameChart[i] = new string[2];
		string givenName;
		string familyName;
		inFile >> givenName >> familyName;
		nameChart[i][0] = givenName;
		nameChart[i][1] = familyName;
		for (int j = 0; j < numExams; j++)
		{
			int testScore;
			inFile >> testScore;
			gradeChart[numStudents][j] += testScore;
			gradeChart[i][j] = testScore;
		}
	}

	//average the test scores into the row after the last student and round to one decimal place
	for (int i = 0; i < numExams; i++)
	{
		gradeChart[numStudents][i] = gradeChart[numStudents][i] / numStudents;
	}

	//total up the number of each grade into the rows after the average
	for (int i = 0; i < numStudents; i++)
	{
		for (int j = 0; j < numExams; j++)
		{
			if (DetermineGrade(gradeChart[i][j], gradeChart[numStudents][j]) == 'A')
			{
				gradeChart[numStudents + 1][j] += 1;
			}
			else if (DetermineGrade(gradeChart[i][j], gradeChart[numStudents][j]) == 'B')
			{
				gradeChart[numStudents + 2][j] += 1;
			}
			else if (DetermineGrade(gradeChart[i][j], gradeChart[numStudents][j]) == 'C')
			{
				gradeChart[numStudents + 3][j] += 1;
			}
			else if (DetermineGrade(gradeChart[i][j], gradeChart[numStudents][j]) == 'D')
			{
				gradeChart[numStudents + 4][j] += 1;
			}
			else if (DetermineGrade(gradeChart[i][j], gradeChart[numStudents][j]) == 'E')
			{
				gradeChart[numStudents + 5][j] += 1;
			}
		}
	}
	
	//output student scores as table
	outFile << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; i++)
	{
		outFile << right << setw(20) << nameChart[i][0] + " " + nameChart[i][1];
		for (int j = 0; j < numExams; j++)
		{
			outFile << setw(7) << gradeChart[i][j];
		}
		outFile << endl;
	}

	//output exam averages as table
	outFile << "Exam Averages:" << endl;
	for (int i = 0; i < numExams; i++)
	{
		outFile << "    Exam " << i + 1 << " Average =   " << fixed << setprecision(1) << gradeChart[numStudents][i] << setprecision(0) << endl;
	}

	//output student scores and grades as table
	outFile << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; i++)
	{
		outFile << right << setw(20) << nameChart[i][0] + " " + nameChart[i][1];
		for (int j = 0; j < numExams; j++)
		{
			outFile << setw(6) << gradeChart[i][j] << "(" << DetermineGrade(gradeChart[i][j], gradeChart[numStudents][j]) << ")";
		}
		outFile << endl;
	}

	//output total of each grade for each exam as table
	outFile << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; i++)
	{
		outFile << setw(8) << "Exam" << setw(3) << i + 1
			<< setw(5) << gradeChart[numStudents + 1][i] << "(A)"
			<< setw(5) << gradeChart[numStudents + 2][i] << "(B)"
			<< setw(5) << gradeChart[numStudents + 3][i] << "(C)"
			<< setw(5) << gradeChart[numStudents + 4][i] << "(D)"
			<< setw(5) << gradeChart[numStudents + 5][i] << "(E)" << endl;
	}

	//average overall exam score and student grades and output final scores and grades as a table
	outFile << "Student Final Grades:" << endl;
	double overallAvg = 0;
	for (int i = 0; i < numStudents; i++)
	{
		for (int j = 0; j < numExams; j++)
		{
			overallAvg += gradeChart[i][j];
		}
	}
	overallAvg = overallAvg / (static_cast<double>(numStudents)* static_cast<double>(numExams));
	for (int i = 0; i < numStudents; i++)
	{
		outFile << right << setw(20) << nameChart[i][0] + " " + nameChart[i][1];
		double studentTotal = 0;
		for (int j = 0; j < numExams; j++)
		{
			studentTotal += gradeChart[i][j];
		}
		double studentAvg = studentTotal / numExams;
		outFile << setw(6) << setprecision(1) << studentAvg << "(" << DetermineGrade(studentAvg, overallAvg) << ")" << endl;
	}
	outFile << "Class Average Score = " << overallAvg;

	//return memory and close files
	for (int i = 0; i < numStudents + 6; i++)
	{
		delete[](gradeChart[i]);
	}
	delete[](gradeChart);
	for (int i = 0; i < numStudents; i++)
	{
		delete[](nameChart[i]);
	}
	delete[](nameChart);
	inFile.close();
	outFile.close();
	return 0;
}