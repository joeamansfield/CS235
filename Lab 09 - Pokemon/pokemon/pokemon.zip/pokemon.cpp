#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK;
#endif

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include "Set.h"
#include "HashMap.h"
using namespace std;

int main(int argc, char** argv) {
	VS_MEM_CHECK;

	if (argc < 3) {
		cerr << "Enter arguments for input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream inFile;
	inFile.open(argv[1]);
	if (!inFile) {
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream outFile;
	outFile.open(argv[2]);
	if (!outFile) {
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	string inputString;
	HashMap<string, string> pokeMap;
	HashMap<string, string> moveMap;
	HashMap<string, Set<string>> effectiveMap;
	HashMap<string, Set<string>> ineffectiveMap;
	for (inputString; getline(inFile, inputString);) {
		stringstream ss;
		string option;
		outFile << inputString;
		ss << inputString;
		ss >> option;
		if (option == "Set:") {
			Set<string> smallSet;
			string item;
			for (item; ss >> item;) {
				smallSet.insert(item);
			}
			outFile << "  [" << smallSet << "]" << endl;
		}

		else if (option == "Pokemon:") {
			string pokemon, type;
			ss >> pokemon >> type;

			pokeMap[pokemon] = type;
		}

		else if (option == "Move:") {
			string move, type;
			ss >> move >> type;
			moveMap[move] = type;
		}

		else if (option == "Effective:") {
			string type1;
			ss >> type1;
			Set<string> effective;
			for (string type2; ss >> type2;) effective.insert(type2);
			effectiveMap[type1] = effective;
		}

		else if (option == "Ineffective:") {
			string type1;
			ss >> type1;
			Set<string> ineffective;
			for (string type2; ss >> type2;) ineffective.insert(type2);
			ineffectiveMap[type1] = ineffective;
		}

		else if (option == "Pokemon") {
			outFile << ": " << pokeMap.size() << "/" << pokeMap.max_size() << endl;
			outFile << pokeMap << endl;
		}

		else if (option == "Moves") {
			outFile << ": " << moveMap.size() << "/" << moveMap.max_size() << endl;
			outFile << moveMap << endl;
		}

		else if (inputString == "Effectivities") {
			outFile << ": " << effectiveMap.size() << "/" << effectiveMap.max_size() << endl;
			outFile << effectiveMap << endl;
		}

		else if (inputString == "Ineffectivities") {
			outFile << ": " << ineffectiveMap.size() << "/" << ineffectiveMap.max_size() << endl;
			outFile << ineffectiveMap << endl;
		}
		outFile << endl;
	}
	inFile.close();
	outFile.close();
	return 0;
}